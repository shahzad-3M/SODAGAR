import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Lock, ShieldAlert } from 'lucide-react';
import {
  AgeGroupType,
  AppUser,
  AttendanceRecord,
  BroadcastContact,
  BusinessProfile,
  CartItem,
  CategoryRecord,
  CODOrder,
  CODOrderStatus,
  Customer,
  Employee,
  GenderType,
  Investor,
  LuckyDrawEvent,
  LuckyDrawWinner,
  MonthlyExpense,
  PaymentMode,
  ProductBroadcast,
  ProductItem,
  RecurringInvoice,
  ReminderTemplate,
  Reseller,
  SalePaymentType,
  SavedBroadcastCampaign,
  TopBuyer,
  Transaction,
  TransactionAuditEntry,
  UserRole,
  WhatsAppNotification,
} from './types/index.ts';
import {
  defaultCustomerUser,
  getActiveRole,
  getAttendance,
  getBroadcastContacts,
  getBusinessProfile,
  getCODOrders,
  getCurrentUser,
  getCustomers,
  getDefaultPinForPhone,
  getEmployees,
  getInvestors,
  getLuckyDraws,
  getProductBroadcasts,
  getProducts,
  getRecurringInvoices,
  getReminderTemplates,
  getResellers,
  getSavedBroadcasts,
  getTransactions,
  getWhatsAppNotifications,
  recalculateCustomerBalances,
  saveActiveRole,
  saveAttendance,
  saveBroadcastContacts,
  saveBusinessProfile,
  saveCODOrders,
  saveCurrentUser,
  saveCustomers,
  saveEmployees,
  saveLuckyDraws,
  saveProductBroadcasts,
  saveProducts,
  saveRecurringInvoices,
  saveReminderTemplates,
  saveResellers,
  saveSavedBroadcasts,
  saveTransactions,
  saveWhatsAppNotifications,
  getCategories,
  getCategoryRecords,
  saveCategories,
  addCategory,
  subscribeToServerSync,
  setSessionToken,
  apiSubmitCheckoutOrder,
  apiUpdateCODOrderStatus,
  apiAuditAndRepairOrders,
  apiSaveProduct,
  apiDeleteProduct,
  apiDeleteExpense,
  apiDeleteCollectionItem,
  getCartItems,
  saveCartItems,
  getMonthlyExpenses,
  saveMonthlyExpenses,
  apiLogCrmActivity,
} from './utils/storage.ts';
import { isProductPurchaseBlocked, normalizeTextKey } from './utils/locationCategoryHelpers.ts';
import {
  buildCustomerPaymentReminderMessage,
  buildSaleInvoiceMessage,
  formatPaymentChannelsText,
  openWhatsAppDirect,
} from './utils/whatsapp.ts';
import {
  computeTopBuyers,
  generateMonthlyRemindersBatch,
  generatePaymentTermsAlertsBatch,
  generateProductBroadcastBatch,
  generateSegmentedBroadcastBatch,
  generateWeeklyDueRemindersBatch,
  runRecurringInvoicesCheck,
} from './utils/automationEngine.ts';
import { Navbar } from './components/Navbar.tsx';
import { StoreCatalogView } from './components/StoreCatalogView.tsx';
import { MonthlyStatementView } from './components/MonthlyStatementView.tsx';
import { InventoryView } from './components/InventoryView.tsx';
import { PaymentTermsView } from './components/PaymentTermsView.tsx';
import { LuckyDrawView } from './components/LuckyDrawView.tsx';
import { CODOrdersView } from './components/CODOrdersView.tsx';
import { HRManagementView } from './components/HRManagementView.tsx';
import { ResellersView } from './components/ResellersView.tsx';
import { LoginRoleModal } from './components/LoginRoleModal.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { CustomersView } from './components/CustomersView.tsx';
import { RecurringInvoicesView } from './components/RecurringInvoicesView.tsx';
import { WhatsAppAutomationView } from './components/WhatsAppAutomationView.tsx';
import { ReportsView } from './components/ReportsView.tsx';
import { TransactionHistoryView } from './components/TransactionHistoryView.tsx';
import { SettingsView } from './components/SettingsView.tsx';
import { CheckoutModal, CheckoutSalePayload } from './components/CheckoutModal.tsx';
import { AddTransactionModal } from './components/AddTransactionModal.tsx';
import { AddCustomerModal } from './components/AddCustomerModal.tsx';
import { ScheduleWhatsAppModal } from './components/ScheduleWhatsAppModal.tsx';
import { AddRecurringInvoiceModal } from './components/AddRecurringInvoiceModal.tsx';
import { ProductBroadcastModal } from './components/ProductBroadcastModal.tsx';
import { InvoiceModal } from './components/InvoiceModal.tsx';
import { UserManagementView } from './components/UserManagementView.tsx';
import { InvestorManagementView } from './components/InvestorManagementView.tsx';
import { CustomerPortalView } from './components/CustomerPortalView.tsx';
import { CategoryManagementModal } from './components/CategoryManagementModal.tsx';
import { BranchManagementView } from './components/BranchManagementView.tsx';
import { WalkInSalesView } from './components/WalkInSalesView.tsx';
import { ProductImporterModal } from './components/ProductImporterModal.tsx';
import { FinancialMasterView } from './components/FinancialMasterView.tsx';
import { CRMWorkspaceView } from './components/CRMWorkspaceView.tsx';
import {
  ToastBanner,
  ToastMessage,
  ConfirmDialogModal,
  ConfirmDialogState,
  InputPromptModal,
  InputPromptState,
} from './components/AppDialogs.tsx';

export default function App() {
  // Main Data States
  const [profile, setProfile] = useState<BusinessProfile>(getBusinessProfile);
  const [products, setProducts] = useState<ProductItem[]>(getProducts);
  const [categoryRecords, setCategoryRecords] = useState<CategoryRecord[]>(getCategoryRecords);
  const [customers, setCustomers] = useState<Customer[]>(() => {
    const rawCusts = getCustomers();
    const rawTxs = getTransactions();
    return recalculateCustomerBalances(rawCusts, rawTxs);
  });
  const [transactions, setTransactions] = useState<Transaction[]>(getTransactions);
  const [recurringInvoices, setRecurringInvoices] = useState<RecurringInvoice[]>(getRecurringInvoices);
  const [notifications, setNotifications] = useState<WhatsAppNotification[]>(getWhatsAppNotifications);
  const [templates, setTemplates] = useState<ReminderTemplate[]>(getReminderTemplates);
  const [productBroadcasts, setProductBroadcasts] = useState<ProductBroadcast[]>(getProductBroadcasts);
  const [luckyDraws, setLuckyDraws] = useState<LuckyDrawEvent[]>(getLuckyDraws);
  const [broadcastContacts, setBroadcastContacts] = useState<BroadcastContact[]>(getBroadcastContacts);
  const [savedBroadcasts, setSavedBroadcasts] = useState<SavedBroadcastCampaign[]>(getSavedBroadcasts);
  const [isWebsiteImportModalOpen, setIsWebsiteImportModalOpen] = useState(false);

  // New Features States: COD Orders, HR, Resellers, User Roles
  const [codOrders, setCODOrders] = useState<CODOrder[]>(getCODOrders);
  const [employees, setEmployees] = useState<Employee[]>(getEmployees);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(getAttendance);
  const [resellers, setResellers] = useState<Reseller[]>(getResellers);
  const [investors, setInvestors] = useState<Investor[]>(getInvestors);
  const [monthlyExpenses, setMonthlyExpenses] = useState<MonthlyExpense[]>(getMonthlyExpenses);
  const [initialProductId, setInitialProductId] = useState<string | null>(() => {
    try {
      return new URLSearchParams(window.location.search).get('product');
    } catch {
      return null;
    }
  });
  const [initialAddToCartParam, setInitialAddToCartParam] = useState<string | null>(() => {
    try {
      return new URLSearchParams(window.location.search).get('add_to_cart');
    } catch {
      return null;
    }
  });
  const [activeRole, setActiveRole] = useState<UserRole>(getActiveRole);
  const [currentUser, setCurrentUser] = useState<AppUser>(getCurrentUser);
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);

  const openRoleModal = () => {
    setIsRoleModalOpen(true);
  };

  // POS / Sale Cart State (persisted per browser session so reloads / external redirects never drop items)
  const [cart, setCart] = useState<CartItem[]>(getCartItems);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  useEffect(() => {
    saveCartItems(cart);
  }, [cart]);

  // Navigation & Filter States
  const [currentTab, setCurrentTab] = useState<string>('store'); // Default to Store & POS Catalog matching screenshot!
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'customer' | 'merchant'>(() => {
    const role = getActiveRole();
    return role === 'customer' ? 'customer' : 'merchant';
  });
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | undefined>(undefined);
  const [crmCustomerFocusId, setCrmCustomerFocusId] = useState<string | undefined>(undefined);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');

  const handleTabChange = (tab: string) => {
    if (tab === 'categories_manage') {
      setIsCategoryModalOpen(true);
      return;
    }

    // Strict Guest Restriction: When nobody is logged in, allow ONLY public catalog & read-only lucky draw showcase
    if (!currentUser?.isAuthenticated) {
      if (tab === 'customer_tickets') {
        pushToast('Please sign in first to create or view support tickets.', 'info');
        setCurrentTab('store');
        setIsRoleModalOpen(true);
        return;
      }
      if (tab !== 'store' && tab !== 'lucky_draw') {
        setCurrentTab('store');
        setIsRoleModalOpen(true);
        return;
      }
      setCurrentTab(tab);
      return;
    }

    if (activeRole === 'customer') {
      const allowed = ['store', 'customer_portal', 'customer_tickets', 'history', 'reports', 'monthly_statement', 'lucky_draw'];
      if (!allowed.includes(tab)) {
        setCurrentTab('store');
        return;
      }
    } else if (activeRole === 'investor') {
      const allowed = ['store', 'investors', 'lucky_draw'];
      if (!allowed.includes(tab)) {
        setCurrentTab('investors');
        return;
      }
    } else if (activeRole === 'reseller') {
      const allowed = ['store', 'resellers', 'history', 'monthly_statement', 'lucky_draw'];
      if (!allowed.includes(tab)) {
        setCurrentTab('resellers');
        return;
      }
    } else if (activeRole === 'manager') {
      const allowed = [
        'store',
        'walkin_pos',
        'branches_manage',
        'inventory',
        'cod_orders',
        'customers',
        'payment_terms',
        'monthly_statement',
        'history',
        'reports',
        'hr_payroll',
        'financial_master',
        'lucky_draw',
        ...(currentUser?.crmPermissions?.canViewCrmDashboard !== false ? ['crm'] : []),
      ];
      if (!allowed.includes(tab)) {
        setCurrentTab('walkin_pos');
        return;
      }
    } else if (activeRole === 'staff') {
      const allowed = [
        'store',
        'walkin_pos',
        'cod_orders',
        'reports',
        'history',
        'lucky_draw',
        ...(currentUser?.crmPermissions?.canViewCrmDashboard !== false ? ['crm'] : []),
      ];
      if (!allowed.includes(tab)) {
        setCurrentTab('walkin_pos');
        return;
      }
    }
    setCurrentTab(tab);
  };

  // Theme State
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return (
      localStorage.getItem('100dagar_theme') === 'dark' ||
      window.matchMedia('(prefers-color-scheme: dark)').matches
    );
  });

  // Modal States
  const [isAddTxOpen, setIsAddTxOpen] = useState(false);
  const [addTxType, setAddTxType] = useState<'credit' | 'debit'>('credit');
  const [addTxCustomerId, setAddTxCustomerId] = useState<string | undefined>(undefined);

  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [isScheduleWhatsAppOpen, setIsScheduleWhatsAppOpen] = useState(false);
  const [scheduleCustomerId, setScheduleCustomerId] = useState<string | undefined>(undefined);
  const [scheduleDate, setScheduleDate] = useState<string | undefined>(undefined);

  const [isAddRecurringOpen, setIsAddRecurringOpen] = useState(false);
  const [isProductBroadcastOpen, setIsProductBroadcastOpen] = useState(false);

  const [invoiceModalTx, setInvoiceModalTx] = useState<Transaction | null>(null);
  const [invoiceModalCustomer, setInvoiceModalCustomer] = useState<Customer | null>(null);

  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [confirmDialog, setConfirmDialog] = useState<ConfirmDialogState | null>(null);
  const [inputPrompt, setInputPrompt] = useState<InputPromptState | null>(null);

  const pushToast = useCallback(
    (text: string, type: ToastMessage['type'] = 'info') => {
      const id = `toast_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      setToasts((prev) => [...prev, { id, text, type }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 4500);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Synchronize Dark Mode with Document Root
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('100dagar_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('100dagar_theme', 'light');
    }
  }, [darkMode]);

  // Recalculate balances and customer purchases whenever transactions change
  const syncTransactionsAndBalances = useCallback(
    (newTxs: Transaction[], newCusts: Customer[]) => {
      const balanced = recalculateCustomerBalances(newCusts, newTxs);
      setCustomers(balanced);
      setTransactions(newTxs);
      saveCustomers(balanced);
      saveTransactions(newTxs);
    },
    []
  );

  // Derived Top Buyers calculation
  const topBuyers = useMemo(() => {
    return computeTopBuyers(customers, transactions);
  }, [customers, transactions]);

  // Centralized Distinct Categories
  const allCategories = useMemo(() => {
    const central = getCategories();
    const fromProds = products.map((p) => p.category?.trim()).filter(Boolean);
    return Array.from(new Set([...central, ...fromProds])).sort((a, b) => a.localeCompare(b));
  }, [products, categoryRecords]);

  // Pending alerts badge count
  const todayStr = new Date().toISOString().split('T')[0];
  const pendingAlertsCount = notifications.filter(
    (n) => n.status === 'pending' && n.scheduledFor <= todayStr
  ).length;

  // Cart Totals
  const cartCount = cart.reduce((acc, it) => acc + it.quantity, 0);
  const cartTotal = cart.reduce((acc, it) => acc + it.unitPrice * it.quantity, 0);

  // Refresh all state from central synced store
  const handleRefreshAllData = useCallback(() => {
    const prof = getBusinessProfile();
    const rawTxs = getTransactions();
    const rawCusts = getCustomers();
    const prods = getProducts();
    const catRecs = getCategoryRecords();
    const recs = getRecurringInvoices();
    const notifs = getWhatsAppNotifications();
    const tpls = getReminderTemplates();
    const bcasts = getProductBroadcasts();
    const draws = getLuckyDraws();
    const bContacts = getBroadcastContacts();
    const savedCamps = getSavedBroadcasts();
    const cods = getCODOrders();
    const emps = getEmployees();
    const atts = getAttendance();
    const resells = getResellers();
    const invs = getInvestors();
    const exps = getMonthlyExpenses();

    const balanced = recalculateCustomerBalances(rawCusts, rawTxs);

    setProfile(prof);
    setProducts(prods);
    setCategoryRecords(catRecs);
    setCustomers(balanced);
    setTransactions(rawTxs);
    setRecurringInvoices(recs);
    setNotifications(notifs);
    setTemplates(tpls);
    setProductBroadcasts(bcasts);
    setLuckyDraws(draws);
    setBroadcastContacts(bContacts);
    setSavedBroadcasts(savedCamps);
    setCODOrders(cods);
    setEmployees(emps);
    setAttendance(atts);
    setResellers(resells);
    setInvestors(invs);
    setMonthlyExpenses(exps);

    const actRole = getActiveRole();
    const curUser = getCurrentUser();
    setActiveRole(actRole);
    setCurrentUser(curUser);
    setViewMode(actRole === 'customer' ? 'customer' : 'merchant');
    if (!curUser?.isAuthenticated) {
      setCurrentTab((prevTab) => {
        if (prevTab !== 'store' && prevTab !== 'lucky_draw') {
          setIsWebsiteImportModalOpen(false);
          setIsRoleModalOpen(true);
          return 'store';
        }
        return prevTab;
      });
    }
  }, []);

  // Live Cross-Device Server Sync (SSE + focus + polling fallback)
  useEffect(() => {
    return subscribeToServerSync(() => {
      handleRefreshAllData();
    });
  }, [handleRefreshAllData]);

  const handleSaveBroadcastContact = (contact: BroadcastContact) => {
    const exists = broadcastContacts.some((c) => c.id === contact.id);
    const updated = exists
      ? broadcastContacts.map((c) => (c.id === contact.id ? contact : c))
      : [contact, ...broadcastContacts];
    setBroadcastContacts(updated);
    saveBroadcastContacts(updated);
  };

  const handleDeleteBroadcastContact = (id: string) => {
    const updated = broadcastContacts.filter((c) => c.id !== id);
    setBroadcastContacts(updated);
    saveBroadcastContacts(updated);
    void apiDeleteCollectionItem('broadcast_contacts', id);
  };

  const handleSaveBroadcastCampaign = (campaign: SavedBroadcastCampaign) => {
    const updated = [campaign, ...savedBroadcasts];
    setSavedBroadcasts(updated);
    saveSavedBroadcasts(updated);
  };

  // CART HANDLERS
  const handleAddToCart = useCallback((product: ProductItem, qty: number = 1, selectedSize?: string) => {
    if (isProductPurchaseBlocked(product)) {
      pushToast(
        `"${product.name}" is in Upcoming Viral Products | Coming Soon and cannot be added to cart until physical arrival is confirmed.`,
        'error'
      );
      return;
    }
    const availableStock = Number(product.stockQty ?? 0);
    if (availableStock <= 0) {
      pushToast(`"${product.name}" is currently out of stock and cannot be added to cart.`, 'error');
      return;
    }
    const unitPrice = Number(product.ourPrice ?? 0);
    if (!Number.isFinite(unitPrice) || unitPrice <= 0) {
      pushToast(`"${product.name}" does not have a valid selling price configured.`, 'error');
      return;
    }
    const resolvedQty = Math.max(1, Math.min(availableStock, Math.round(qty || 1)));
    const resolvedSize = selectedSize || product.selectedSize || '';
    const productWithSize = resolvedSize ? { ...product, selectedSize: resolvedSize } : product;
    const unitSavings = Math.max(0, Number(product.marketPrice || unitPrice) - unitPrice);

    setCart((prevCart) => {
      const existing = prevCart.find(
        (it) =>
          it.product.id === product.id &&
          (it.product.selectedSize || '') === resolvedSize &&
          it.unitPrice === unitPrice
      );
      if (existing) {
        const updatedQty = Math.min(availableStock, existing.quantity + resolvedQty);
        return prevCart.map((it) =>
          it.product.id === product.id &&
          (it.product.selectedSize || '') === resolvedSize &&
          it.unitPrice === unitPrice
            ? {
                ...it,
                quantity: updatedQty,
                totalAmount: it.unitPrice * updatedQty,
                totalSavings: unitSavings * updatedQty,
              }
            : it
        );
      }
      const newItem: CartItem = {
        product: productWithSize,
        quantity: resolvedQty,
        unitPrice,
        marketPrice: Math.max(unitPrice, Number(product.marketPrice || unitPrice)),
        unitSavings,
        totalAmount: unitPrice * resolvedQty,
        totalSavings: unitSavings * resolvedQty,
      };
      return [...prevCart, newItem];
    });
    pushToast(
      `Added "${product.name}"${resolvedSize ? ` (${resolvedSize})` : ''} to cart.`,
      'success'
    );
    void apiLogCrmActivity({
      customerId: currentUser?.customerId,
      phone: currentUser?.phone,
      eventType: 'cart_add',
      productId: product.id,
      productName: product.name,
      category: product.category,
      amount: unitPrice * resolvedQty,
    });
  }, [pushToast, currentUser?.customerId, currentUser?.phone]);

  // Support deep-link ?add_to_cart=<id|sku|slug> from website links (e.g. www.madinamarket.pk)
  useEffect(() => {
    if (!initialAddToCartParam || products.length === 0) return;
    const key = normalizeTextKey(initialAddToCartParam);
    const matched = products.find((p) => {
      if (p.id === initialAddToCartParam || normalizeTextKey(p.id) === key) return true;
      if (p.sku && normalizeTextKey(p.sku) === key) return true;
      const slugMatch = (p.websiteUrl || p.sourceUrl || '').toLowerCase().includes(initialAddToCartParam.toLowerCase());
      return Boolean(slugMatch);
    });
    setInitialAddToCartParam(null);
    try {
      const url = new URL(window.location.href);
      if (url.searchParams.has('add_to_cart')) {
        url.searchParams.delete('add_to_cart');
        window.history.replaceState({}, '', url.pathname + url.search + url.hash);
      }
    } catch {
      // ignore history errors
    }
    if (matched) {
      handleAddToCart(matched, 1);
      setIsCheckoutOpen(true);
    } else {
      pushToast(`Product "${initialAddToCartParam}" was not found in the local catalog.`, 'warning');
    }
  }, [initialAddToCartParam, products, handleAddToCart, pushToast]);

  const handleUpdateCartQty = (productId: string, qty: number, selectedSize?: string) => {
    const targetIdx = cart.findIndex(
      (it) =>
        it.product.id === productId &&
        (selectedSize === undefined || (it.product.selectedSize || '') === (selectedSize || ''))
    );
    if (targetIdx === -1) return;
    if (qty <= 0) {
      setCart(cart.filter((_, idx) => idx !== targetIdx));
      return;
    }
    const maxStock = Number(cart[targetIdx].product.stockQty ?? 0);
    const cappedQty = maxStock > 0 ? Math.min(maxStock, qty) : qty;
    const updated = cart.map((it, idx) =>
      idx === targetIdx
        ? {
            ...it,
            quantity: cappedQty,
            totalAmount: it.unitPrice * cappedQty,
            totalSavings: it.unitSavings * cappedQty,
          }
        : it
    );
    setCart(updated);
  };

  const handleRemoveFromCart = (productId: string, selectedSize?: string) => {
    if (selectedSize === undefined) {
      setCart(cart.filter((it) => it.product.id !== productId));
    } else {
      setCart(
        cart.filter(
          (it) => !(it.product.id === productId && (it.product.selectedSize || '') === (selectedSize || ''))
        )
      );
    }
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // COMPLETE SALE (Full Payment or Cash on Delivery with Basic Checkout Form)
  const handleCompleteSale = async (
    saleData: CheckoutSalePayload
  ): Promise<{ ok: boolean; error?: string }> => {
    if (cart.length === 0) {
      const msg = 'Cart is empty. Please add at least one product before placing an order.';
      pushToast(msg, 'error');
      return { ok: false, error: msg };
    }
    if (cart.some((it) => isProductPurchaseBlocked(it.product))) {
      const msg =
        'Checkout blocked: Upcoming / Coming Soon items cannot be ordered until physical arrival is confirmed.';
      pushToast(msg, 'error');
      return { ok: false, error: msg };
    }

    const cleanPhone = saleData.buyerDetails.phone.replace(/\D/g, '');
    let activeCustomers = [...customers];
    let customer =
      saleData.customerId && saleData.customerId !== 'new_checkout_buyer'
        ? activeCustomers.find((c) => c.id === saleData.customerId)
        : undefined;

    if (!customer && cleanPhone) {
      customer = activeCustomers.find((c) => c.phone.replace(/\D/g, '') === cleanPhone);
    }

    if (!customer) {
      const newCustId = `cust_${Date.now()}`;
      customer = {
        id: newCustId,
        name: saleData.buyerDetails.name,
        phone: saleData.buyerDetails.phone,
        city: saleData.buyerDetails.city || 'Muzaffarabad',
        area: saleData.buyerDetails.area || saleData.buyerDetails.address,
        mohalla: saleData.buyerDetails.mohalla,
        landmark: saleData.buyerDetails.landmark,
        address: saleData.buyerDetails.address,
        customerType: 'individual',
        balance: 0,
        totalPurchases: 0,
        creditLimit: 5000,
        paymentTermsDays: 7,
        status: 'active',
        pin: getDefaultPinForPhone(saleData.buyerDetails.phone),
        createdAt: todayStr,
      };
      activeCustomers = [customer, ...activeCustomers];
    } else {
      // Update delivery details if provided
      customer = {
        ...customer,
        name: saleData.buyerDetails.name || customer.name,
        city: saleData.buyerDetails.city || customer.city,
        area: saleData.buyerDetails.area || customer.area,
        mohalla: saleData.buyerDetails.mohalla || customer.mohalla,
        landmark: saleData.buyerDetails.landmark || customer.landmark,
        address: saleData.buyerDetails.address || customer.address,
      };
      activeCustomers = activeCustomers.map((c) => (c.id === customer!.id ? customer! : c));
    }

    const invoiceNumber = `INV-100D-${Math.floor(1000 + Math.random() * 9000)}`;

    const totalSavings = cart.reduce((acc, it) => acc + it.totalSavings, 0);
    const totalAmount = cart.reduce((acc, it) => acc + it.totalAmount, 0);
    const deliveryFee = Math.max(0, Math.round(Number(saleData.deliveryFee || 0)));
    const orderTotalWithDelivery = totalAmount + deliveryFee;

    const txItems = cart.map((it) => ({
      productId: it.product.id,
      description: `${it.product.name}${it.product.selectedSize ? ` (${it.product.selectedSize})` : ''}`,
      quantity: it.quantity,
      unitPrice: it.unitPrice,
      marketPrice: it.marketPrice,
      amount: it.totalAmount,
      customerSavings: it.totalSavings,
    }));

    const isCreditAuthorizedSeller =
      currentUser?.isAuthenticated === true &&
      (activeRole === 'super_admin' ||
        activeRole === 'admin' ||
        ((activeRole === 'manager' || activeRole === 'staff') &&
          Boolean(
            currentUser.canAuthorizeCreditSale ||
              currentUser.managerAuthorities?.canAuthorizeCreditSale
          )));

    const effectiveSaleType: SalePaymentType =
      saleData.saleType === 'time_credit' && isCreditAuthorizedSeller
        ? 'time_credit'
        : saleData.saleType === 'cod'
        ? 'cod'
        : 'full';

    const initialStatus =
      effectiveSaleType === 'cod' || effectiveSaleType === 'time_credit' ? 'pending' : 'completed';

    const staffName =
      activeRole === 'admin' || activeRole === 'super_admin'
        ? currentUser.name || 'Super Admin'
        : currentUser.name || 'Online Checkout';

    let softReminderDate: string | undefined;
    let maxGraceDate: string | undefined;
    if (effectiveSaleType === 'time_credit' && saleData.dueDate) {
      const softObj = new Date(saleData.dueDate);
      softObj.setDate(softObj.getDate() - 3);
      softReminderDate = softObj.toISOString().split('T')[0];

      const graceObj = new Date(saleData.dueDate);
      graceObj.setDate(graceObj.getDate() + 7);
      maxGraceDate = graceObj.toISOString().split('T')[0];
    }

    const txNoteWithFee =
      deliveryFee > 0
        ? `${saleData.notes} [Delivery: ${saleData.buyerDetails.city}${
            saleData.buyerDetails.area ? ` (${saleData.buyerDetails.area})` : ''
          } +Rs. ${deliveryFee}]`
        : saleData.notes;

    // 1. Create Transaction with Permanent Audit Trail
    const newTx: Transaction = {
      id: `tx_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      customerId: customer.id,
      type: 'credit',
      amount: orderTotalWithDelivery,
      paidAmount: effectiveSaleType === 'full' ? orderTotalWithDelivery : 0,
      dueBalance: effectiveSaleType === 'time_credit' ? orderTotalWithDelivery : 0,
      saleType: effectiveSaleType,
      date: todayStr,
      dueDate: saleData.dueDate,
      paymentTermsDays: effectiveSaleType === 'time_credit' ? saleData.paymentTermsDays || 7 : 0,
      softReminderDate,
      maxGraceDate,
      invoiceNumber,
      notes: txNoteWithFee,
      paymentMode: effectiveSaleType === 'cod' ? 'cod' : effectiveSaleType === 'time_credit' ? 'other' : saleData.paymentMode,
      items: txItems,
      totalSavings,
      status: initialStatus,
      responsibleStaff: staffName,
      auditTrail: [
        {
          id: `audit_chk_${Date.now()}`,
          timestamp: new Date().toISOString(),
          action: 'created',
          newStatus: initialStatus,
          newAmount: orderTotalWithDelivery,
          changedBy: staffName,
          notes: `Order created via checkout (${effectiveSaleType.toUpperCase()}) with ${txItems.length} items${
            deliveryFee > 0 ? ` + Rs. ${deliveryFee} delivery` : ''
          }${effectiveSaleType === 'time_credit' ? ` [Credit authorized by ${staffName}]` : ''}`,
        },
      ],
      createdAt: new Date().toISOString(),
    };

    const updatedTxs = [newTx, ...transactions];
    const balancedCustomers = recalculateCustomerBalances(activeCustomers, updatedTxs);
    const balancedCustomer = balancedCustomers.find((c) => c.id === customer!.id) || customer;

    // 2. If COD sale: Build COD Order for Logistics Hub
    let newCODOrder: CODOrder | undefined;
    if (effectiveSaleType === 'cod') {
      const codTotal = totalAmount + deliveryFee;
      const commissionAmount = saleData.resellerCode ? Math.floor(totalAmount / 1000) * 30 : 0;
      newCODOrder = {
        id: `cod_${Date.now()}`,
        orderNumber: `COD-100D-${Math.floor(100 + Math.random() * 900)}`,
        customerId: customer.id,
        customerName: saleData.buyerDetails.name || customer.name,
        phone: saleData.buyerDetails.phone || customer.phone,
        city: saleData.buyerDetails.city || customer.city || 'Muzaffarabad',
        area: saleData.buyerDetails.area || customer.area,
        mohalla: saleData.buyerDetails.mohalla || customer.mohalla,
        landmark: saleData.buyerDetails.landmark || customer.landmark,
        address: saleData.buyerDetails.address || customer.address || 'Address provided',
        items: txItems,
        subtotal: totalAmount,
        deliveryFee,
        totalAmount: codTotal,
        courierPartner: 'WASAL delivery',
        trackingNumber: `WSL-${Math.floor(100000 + Math.random() * 900000)}`,
        status: 'pending',
        resellerCode: saleData.resellerCode,
        commissionAmount,
        notes: saleData.notes,
        createdAt: new Date().toISOString(),
      };
    }

    const matchedReseller = saleData.resellerCode
      ? resellers.find((r) => r.referralCode.toLowerCase() === saleData.resellerCode!.toLowerCase())
      : undefined;

    // 3. Submit atomically to SQLite backend for authoritative stock & city validation + multi-device sync
    const checkoutResult = await apiSubmitCheckoutOrder({
      items: cart.map((it) => ({ productId: it.product.id, quantity: it.quantity })),
      customer: balancedCustomer,
      transaction: newTx,
      codOrder: newCODOrder,
      resellerId: matchedReseller?.id,
    });

    if (!checkoutResult.ok) {
      const errMsg = checkoutResult.error || 'Checkout validation failed.';
      pushToast(errMsg, 'error');
      return { ok: false, error: errMsg };
    }

    handleRefreshAllData();

    // 4. Clear Cart & Close Modal
    setCart([]);
    setIsCheckoutOpen(false);

    // 5. Send Instant WhatsApp Invoice if selected
    if (saleData.sendWhatsApp && customer) {
      const msg = buildSaleInvoiceMessage(customer, newTx, profile);
      openWhatsAppDirect(customer.phone, msg);

      // Log notification
      const logNotif: WhatsAppNotification = {
        id: `notif_sale_${Date.now()}`,
        customerId: customer.id,
        customerName: customer.name,
        phone: customer.phone,
        amount: saleData.dueBalance > 0 ? saleData.dueBalance : totalAmount,
        dueDate: saleData.dueDate,
        scheduledFor: todayStr,
        type: 'payment_receipt',
        status: 'sent',
        messageText: msg,
        sentAt: new Date().toISOString(),
        notes: `Instant sale receipt (${saleData.saleType}) with savings breakdown`,
        createdAt: new Date().toISOString(),
      };
      const updatedNotifs = [logNotif, ...notifications];
      setNotifications(updatedNotifs);
      saveWhatsAppNotifications(updatedNotifs);
    }

    pushToast(
      `کامیابی سے بل #${invoiceNumber} بنام ${customer?.name || 'کسٹمر'} درج کر لیا گیا! Customer savings: ${profile.currencySymbol}${totalSavings.toLocaleString('en-PK')}. Stock updated.`,
      'success'
    );
    return { ok: true };
  };

  // COD ORDERS LOGISTICS HANDLERS
  const handleUpdateCODStatus = async (
    orderId: string,
    newStatus: CODOrderStatus,
    details?: { courierPartner?: CODOrder['courierPartner']; trackingNumber?: string }
  ) => {
    const serverRes = await apiUpdateCODOrderStatus(orderId, newStatus, details);
    if (serverRes.ok) {
      handleRefreshAllData();
      return;
    }
    if (serverRes.error && !serverRes.error.toLowerCase().includes('network')) {
      pushToast(serverRes.error, 'error');
    }

    let updatedProducts = [...products];
    let updatedTxs = [...transactions];
    let updatedResellers = [...resellers];

    const updatedOrders = codOrders.map((ord) => {
      if (ord.id === orderId) {
        const wasNotDelivered = ord.status !== 'delivered';
        const wasNotReturned = ord.status !== 'returned';

        const updated: CODOrder = {
          ...ord,
          status: newStatus,
          courierPartner: details?.courierPartner || ord.courierPartner,
          trackingNumber: details?.trackingNumber || ord.trackingNumber,
          dispatchedAt: newStatus === 'dispatched' ? new Date().toISOString() : ord.dispatchedAt,
          deliveredAt: newStatus === 'delivered' ? new Date().toISOString() : ord.deliveredAt,
          returnedAt: newStatus === 'returned' ? new Date().toISOString() : ord.returnedAt,
        };

        if (newStatus === 'delivered' && wasNotDelivered) {
          const netCash = ord.totalAmount - ord.deliveryFee;
          const cleanOrdPhone = (ord.phone || '').replace(/\D/g, '');
          const matchedCust =
            (ord.customerId && customers.find((c) => c.id === ord.customerId)) ||
            (cleanOrdPhone &&
              customers.find((c) => c.phone.replace(/\D/g, '') === cleanOrdPhone)) ||
            undefined;
          const debitTx: Transaction = {
            id: `tx_cod_deliv_${Date.now()}`,
            customerId: matchedCust?.id || ord.customerId || '',
            type: 'debit',
            amount: ord.totalAmount,
            date: todayStr,
            paymentMode: 'cod',
            invoiceNumber: ord.orderNumber,
            notes: `COD Settlement #${ord.orderNumber} (${ord.courierPartner}) - Net Cash Rs. ${netCash.toLocaleString('en-PK')}`,
            createdAt: new Date().toISOString(),
          };
          updatedTxs = [debitTx, ...updatedTxs];

          if (ord.resellerCode) {
            const earned = Math.floor(ord.subtotal / 1000) * 30;
            updatedResellers = updatedResellers.map((r) =>
              r.referralCode === ord.resellerCode
                ? {
                    ...r,
                    totalReferredOrders: r.totalReferredOrders + 1,
                    totalSales: r.totalSales + ord.subtotal,
                    totalPaidSales: r.totalPaidSales + ord.subtotal,
                    earnedCommission: r.earnedCommission + earned,
                  }
                : r
            );
          }
        }

        if (newStatus === 'returned' && wasNotReturned) {
          updatedProducts = updatedProducts.map((p) => {
            const ordItem = (ord.items || []).find((it) => it.productId === p.id);
            if (ordItem) {
              return {
                ...p,
                stockQty: p.stockQty + ordItem.quantity,
              };
            }
            return p;
          });
        }

        return updated;
      }
      return ord;
    });

    setCODOrders(updatedOrders);
    saveCODOrders(updatedOrders);

    if (updatedProducts !== products) {
      setProducts(updatedProducts);
      saveProducts(updatedProducts);
    }

    if (updatedTxs !== transactions) {
      syncTransactionsAndBalances(updatedTxs, customers);
    }

    if (updatedResellers !== resellers) {
      setResellers(updatedResellers);
      saveResellers(updatedResellers);
    }
  };

  const handleAuditRepairOrders = async () => {
    const res = await apiAuditAndRepairOrders();
    if (!res.ok) {
      pushToast(res.error || 'Failed to audit and repair backend order history.', 'error');
      return;
    }
    handleRefreshAllData();
    pushToast(res.summary || 'Backend order history audited & cleaned.', 'success');
  };

  const handleAddNewCODOrder = (order: CODOrder) => {
    const cleanPhone = (order.phone || '').replace(/\D/g, '');
    let activeCustomers = [...customers];
    let matchedCustomer =
      (order.customerId && activeCustomers.find((c) => c.id === order.customerId)) ||
      (cleanPhone && activeCustomers.find((c) => c.phone.replace(/\D/g, '') === cleanPhone)) ||
      undefined;

    if (!matchedCustomer && order.customerName) {
      matchedCustomer = {
        id: `cust_ord_${Date.now()}`,
        name: order.customerName,
        phone: order.phone,
        city: order.city || 'Muzaffarabad',
        area: order.area,
        mohalla: order.mohalla,
        landmark: order.landmark,
        address: order.address || order.city || 'Pakistan',
        customerType: 'individual',
        balance: order.totalAmount,
        totalPurchases: order.totalAmount,
        creditLimit: 5000,
        paymentTermsDays: 7,
        status: 'active',
        pin: getDefaultPinForPhone(order.phone || '03000000000'),
        createdAt: todayStr,
      };
      activeCustomers = [matchedCustomer, ...activeCustomers];
      setCustomers(activeCustomers);
      saveCustomers(activeCustomers);
    }

    const linkedOrder: CODOrder = {
      ...order,
      customerId: matchedCustomer?.id || order.customerId,
    };

    const updated = [linkedOrder, ...codOrders];
    setCODOrders(updated);
    saveCODOrders(updated);

    const linkedTx: Transaction = {
      id: `tx_link_${linkedOrder.id}`,
      customerId: matchedCustomer?.id || '',
      type: 'credit',
      amount: linkedOrder.totalAmount,
      paidAmount: 0,
      dueBalance: linkedOrder.totalAmount,
      saleType: 'cod',
      date: todayStr,
      dueDate: todayStr,
      paymentTermsDays: 0,
      invoiceNumber: linkedOrder.orderNumber,
      notes: `COD Order #${linkedOrder.orderNumber} (${linkedOrder.city})`,
      paymentMode: 'cod',
      items: linkedOrder.items,
      totalSavings: (linkedOrder.items || []).reduce((acc, it) => acc + Number(it.customerSavings || 0), 0),
      status: 'pending',
      responsibleStaff: currentUser?.name || 'Admin / Logistics',
      auditTrail: [
        {
          id: `aud_cod_${Date.now()}`,
          timestamp: new Date().toISOString(),
          action: 'created',
          newStatus: 'pending',
          newAmount: linkedOrder.totalAmount,
          changedBy: currentUser?.name || 'Admin / Logistics',
          notes: `COD parcel #${linkedOrder.orderNumber} created via logistics desk`,
        },
      ],
      createdAt: linkedOrder.createdAt,
    };
    syncTransactionsAndBalances([linkedTx, ...transactions], activeCustomers);

    // Decrement stock for the items
    const updatedProducts = products.map((p) => {
      const it = (linkedOrder.items || []).find((item) => item.productId === p.id);
      if (it) {
        return { ...p, stockQty: Math.max(0, p.stockQty - it.quantity) };
      }
      return p;
    });
    setProducts(updatedProducts);
    saveProducts(updatedProducts);
  };

  // HR MANAGEMENT HANDLERS
  const handleSaveEmployee = (emp: Employee) => {
    const exists = employees.some((e) => e.id === emp.id);
    const updated = exists ? employees.map((e) => (e.id === emp.id ? emp : e)) : [emp, ...employees];
    setEmployees(updated);
    saveEmployees(updated);
  };

  const handleSaveAttendance = (record: AttendanceRecord) => {
    const exists = attendance.some((a) => a.id === record.id || (a.employeeId === record.employeeId && a.date === record.date));
    const updated = exists
      ? attendance.map((a) =>
          a.id === record.id || (a.employeeId === record.employeeId && a.date === record.date) ? record : a
        )
      : [record, ...attendance];
    setAttendance(updated);
    saveAttendance(updated);
  };

  const handleDeleteEmployee = (empId: string) => {
    const updated = employees.filter((e) => e.id !== empId);
    setEmployees(updated);
    saveEmployees(updated);
    void apiDeleteCollectionItem('employees', empId);
    pushToast('Employee record removed.', 'info');
  };

  const handleDeleteAttendance = (recId: string) => {
    const updated = attendance.filter((a) => a.id !== recId);
    setAttendance(updated);
    saveAttendance(updated);
    void apiDeleteCollectionItem('attendance', recId);
    pushToast('Attendance entry deleted.', 'info');
  };

  // MONTHLY EXPENSES & FINANCIAL MASTER HANDLERS
  const handleSaveMonthlyExpense = (expense: MonthlyExpense) => {
    const exists = monthlyExpenses.some((e) => e.id === expense.id);
    const updated = exists
      ? monthlyExpenses.map((e) => (e.id === expense.id ? expense : e))
      : [expense, ...monthlyExpenses];
    setMonthlyExpenses(updated);
    saveMonthlyExpenses(updated);
  };

  const handleDeleteMonthlyExpense = (expenseId: string) => {
    const updated = monthlyExpenses.filter((e) => e.id !== expenseId);
    setMonthlyExpenses(updated);
    saveMonthlyExpenses(updated);
    void apiDeleteExpense(expenseId);
  };

  const handleCloneRecurringExpenses = (fromMonth: string, toMonth: string): number => {
    const recurringSource = monthlyExpenses.filter(
      (e) => e.isRecurringMonthly && (e.month === fromMonth || e.date.startsWith(fromMonth))
    );
    if (recurringSource.length === 0) return 0;

    const existingToMonthTitles = new Set(
      monthlyExpenses
        .filter((e) => e.month === toMonth || e.date.startsWith(toMonth))
        .map((e) => e.title.trim().toLowerCase())
    );

    const cloned: MonthlyExpense[] = [];
    recurringSource.forEach((src, idx) => {
      if (existingToMonthTitles.has(src.title.trim().toLowerCase())) return;
      const dayPart = src.date.slice(8, 10) || '01';
      cloned.push({
        ...src,
        id: `exp_${Date.now()}_${idx}_${Math.random().toString(36).slice(2, 5)}`,
        month: toMonth,
        date: `${toMonth}-${dayPart}`,
        paymentStatus: 'pending',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    });

    if (cloned.length > 0) {
      const updated = [...cloned, ...monthlyExpenses];
      setMonthlyExpenses(updated);
      saveMonthlyExpenses(updated);
    }
    return cloned.length;
  };

  // RESELLER ACCOUNTS HANDLERS
  const handleSaveReseller = (reseller: Reseller) => {
    const exists = resellers.some((r) => r.id === reseller.id);
    const updated = exists ? resellers.map((r) => (r.id === reseller.id ? reseller : r)) : [reseller, ...resellers];
    setResellers(updated);
    saveResellers(updated);
  };

  const handlePayoutCommission = (resellerId: string, amount: number) => {
    const updated = resellers.map((r) =>
      r.id === resellerId ? { ...r, paidCommission: r.paidCommission + amount } : r
    );
    setResellers(updated);
    saveResellers(updated);
    pushToast(`کامیابی سے رقم Rs. ${amount.toLocaleString('en-PK')} کمیشن واؤچر جاری کر دیا گیا!`, 'success');
  };

  // USER ROLE SELECTION & LOGIN HANDLER
  const handleSelectRole = (newRole: UserRole, userDetails?: Partial<AppUser>) => {
    setActiveRole(newRole);
    saveActiveRole(newRole);

    let updatedUser: AppUser;
    if (userDetails?.isAuthenticated === false) {
      updatedUser = { ...defaultCustomerUser };
    } else if (userDetails) {
      updatedUser = {
        ...userDetails,
        id: userDetails.id || currentUser.id,
        name: userDetails.name || currentUser.name,
        phone: userDetails.phone ?? currentUser.phone ?? '',
        whatsapp: userDetails.whatsapp ?? currentUser.whatsapp,
        whatsappSameAsPhone: userDetails.whatsappSameAsPhone ?? currentUser.whatsappSameAsPhone,
        email: userDetails.email ?? currentUser.email,
        role: newRole,
        isAuthenticated: userDetails.isAuthenticated ?? true,
      };
    } else if (newRole === 'super_admin' || newRole === 'admin') {
      updatedUser = {
        id: 'usr_superadmin',
        name: 'Shahzad Malik',
        urduName: 'شہزاد ملک (سپر ایڈمن)',
        role: newRole,
        phone: '03125256266',
        email: 'admin@madinamarket.pk',
        resellerCode: 'RES-100D-01',
        isAuthenticated: true,
      };
    } else if (newRole === 'investor') {
      updatedUser = {
        id: 'user_investor_1',
        name: 'Chaudhry Nadeem (Investor)',
        urduName: 'چوہدری ندیم (انویسٹر)',
        role: 'investor',
        phone: '03009876543',
        investorId: 'inv_1',
        isAuthenticated: true,
      };
    } else if (newRole === 'reseller') {
      updatedUser = {
        id: 'user_reseller_1',
        name: 'Usman Ghani',
        urduName: 'عثمان غنی (ری سیلر)',
        role: 'reseller',
        phone: '03125256266',
        resellerCode: 'RES-100D-01',
        isAuthenticated: true,
      };
    } else if (newRole === 'manager' || newRole === 'staff') {
      updatedUser = {
        id: `user_${newRole}_1`,
        name: newRole === 'manager' ? 'Branch Manager' : 'Sales Staff',
        urduName: newRole === 'manager' ? 'برانچ مینیجر' : 'اسٹور اسٹاف',
        role: newRole,
        phone: '03125256266',
        isAuthenticated: true,
      };
    } else {
      updatedUser = { ...defaultCustomerUser };
    }

    setCurrentUser(updatedUser);
    saveCurrentUser(updatedUser);

    if (newRole === 'customer') {
      setViewMode('customer');
      const latestCustomers = getCustomers();
      if (userDetails?.customerId && userDetails?.phone && userDetails.phone !== '03125256266') {
        const cleanPhone = userDetails.phone.replace(/\D/g, '');
        const exists = latestCustomers.some(
          (c) => c.id === userDetails.customerId || c.phone.replace(/\D/g, '') === cleanPhone
        );
        if (!exists) {
          const newCustRecord: Customer = {
            id: userDetails.customerId,
            name: userDetails.name || `Customer ${cleanPhone.slice(-4)}`,
            urduName: userDetails.urduName || 'آن لائن کسٹمر',
            phone: userDetails.phone,
            whatsapp: userDetails.whatsapp || userDetails.phone,
            whatsappSameAsPhone: userDetails.whatsappSameAsPhone ?? true,
            whatsappConsent: true,
            email: userDetails.email,
            city: 'Muzaffarabad',
            customerType: 'individual',
            balance: 0,
            totalPurchases: 0,
            creditLimit: 5000,
            paymentTermsDays: 7,
            status: 'active',
            createdAt: new Date().toISOString(),
          };
          const updatedCusts = [newCustRecord, ...latestCustomers];
          setCustomers(updatedCusts);
          saveCustomers(updatedCusts);
        } else {
          setCustomers(latestCustomers);
        }
      } else {
        setCustomers(latestCustomers);
      }
      setCurrentTab(updatedUser.isAuthenticated ? 'customer_portal' : 'store');
    } else if (newRole === 'investor') {
      setViewMode('merchant');
      setCurrentTab('investors');
    } else if (newRole === 'reseller') {
      setViewMode('merchant');
      setCurrentTab('resellers');
    } else if (newRole === 'manager' || newRole === 'staff') {
      setViewMode('merchant');
      setCurrentTab('walkin_pos');
    } else {
      setViewMode('merchant');
      setCurrentTab('dashboard');
    }
  };

  const handleLogout = () => {
    setSessionToken(null);
    setActiveRole('customer');
    saveActiveRole('customer');
    setCurrentUser(defaultCustomerUser);
    saveCurrentUser(defaultCustomerUser);
    setViewMode('customer');
    setCurrentTab('store');
  };

  // INVENTORY PRODUCT HANDLERS
  const handleSaveProduct = (product: ProductItem) => {
    const exists = products.some((p) => p.id === product.id);
    let updated: ProductItem[];
    if (exists) {
      updated = products.map((p) => (p.id === product.id ? product : p));
    } else {
      updated = [product, ...products];
    }
    setProducts(updated);
    saveProducts(updated);
    void apiSaveProduct(product, exists).then((res) => {
      if (!res.ok) {
        pushToast(res.error || `Product "${product.name}" saved locally, server sync pending.`, 'info');
      } else if (res.product) {
        setProducts((prev) => prev.map((p) => (p.id === res.product!.id ? res.product! : p)));
      }
    });
    pushToast(`Product "${product.name}" saved to catalog.`, 'success');
  };

  const handleUpdateStock = (productId: string, newStock: number) => {
    const targetProd = products.find((p) => p.id === productId);
    if (targetProd && isProductPurchaseBlocked(targetProd) && newStock > 0) {
      pushToast('Upcoming / Coming Soon items keep 0 stock until physical arrival is confirmed.', 'error');
      return;
    }
    const updated = products.map((p) =>
      p.id === productId ? { ...p, stockQty: Math.max(0, newStock) } : p
    );
    setProducts(updated);
    saveProducts(updated);
  };

  const handleToggleWinningItem = (productId: string) => {
    const updated = products.map((p) =>
      p.id === productId ? { ...p, isWinningItem: !p.isWinningItem } : p
    );
    setProducts(updated);
    saveProducts(updated);
  };

  const handleDeleteProduct = (productId: string) => {
    const prod = products.find((p) => p.id === productId);
    setConfirmDialog({
      title: 'Delete Product',
      message: `Are you sure you want to remove "${prod?.name || 'this product'}" from catalog?`,
      confirmLabel: 'Delete',
      danger: true,
      onConfirm: () => {
        const updated = products.filter((p) => p.id !== productId);
        setProducts(updated);
        saveProducts(updated);
        void apiDeleteProduct(productId);
        pushToast('Product removed from catalog.', 'info');
      },
    });
  };

  // PAYMENT TERMS AUTOMATION ENGINE TRIGGER
  const handleRunPaymentTermsEngine = () => {
    const newNotifs = generatePaymentTermsAlertsBatch(transactions, customers, profile, templates);

    if (newNotifs.length === 0) {
      pushToast(
        'تمام ادھار کھاتے اپ ٹو ڈیٹ ہیں۔ All payment terms are up to date. No new 3-day alerts due today.',
        'info'
      );
      return;
    }

    const updatedNotifs = [...newNotifs, ...notifications];
    setNotifications(updatedNotifs);
    saveWhatsAppNotifications(updatedNotifs);

    pushToast(
      `۳ روزہ ادائیگی الرٹ سسٹم: Queued ${newNotifs.length} payment terms alerts (3 days soft notices & overdue cycle).`,
      'success'
    );
  };

  const handleSendSingleTermsReminder = (tx: Transaction, customer: Customer) => {
    const unpaid = tx.dueBalance !== undefined ? tx.dueBalance : tx.amount;
    const paymentChannelsText = formatPaymentChannelsText(profile);
    const msg = `*ادائیگی یاددہانی / Payment Terms Notice*\n*${profile.name} · مدینہ مارکیٹ*\n\nمحترم ${customer.name}${customer.urduName ? ` (${customer.urduName})` : ''} صاحب،\nآپ کے بل #${tx.invoiceNumber || 'INV'} برائے رقم *${profile.currencySymbol}${unpaid.toLocaleString('en-PK')}* کی ادائیگی کی آخری تاریخ *${tx.dueDate}* ہے۔\n\n*Payment Accounts (EasyPaisa / JazzCash / SadaPay: 03125256266):*\n${paymentChannelsText}\n\nبرائے مہربانی بروقت ادائیگی فرما کر کھاتہ کلیئر کریں۔ جزاک اللہ!`;

    openWhatsAppDirect(customer.phone, msg);

    const logNotif: WhatsAppNotification = {
      id: `notif_terms_${Date.now()}`,
      customerId: customer.id,
      customerName: customer.name,
      phone: customer.phone,
      amount: unpaid,
      dueDate: tx.dueDate,
      scheduledFor: todayStr,
      type: 'payment_reminder',
      status: 'sent',
      messageText: msg,
      sentAt: new Date().toISOString(),
      notes: `Single terms alert for #${tx.invoiceNumber}`,
      createdAt: new Date().toISOString(),
    };
    const updated = [logNotif, ...notifications];
    setNotifications(updated);
    saveWhatsAppNotifications(updated);
  };

  const handleSettleTermsPayment = (tx: Transaction, customer: Customer) => {
    const unpaid = tx.dueBalance !== undefined ? tx.dueBalance : tx.amount;
    const staffLabel =
      activeRole === 'admin' || activeRole === 'super_admin'
        ? currentUser.name || 'Super Admin'
        : currentUser.name || 'Store Staff';

    setInputPrompt({
      title: 'Settle Terms Payment',
      label: `Enter payment amount received from ${customer.name} (Current Due: Rs. ${unpaid.toLocaleString('en-PK')}):`,
      initialValue: String(unpaid),
      inputType: 'number',
      submitLabel: 'Record Payment',
      onSubmit: (amountToSettle) => {
        const settledNum = parseFloat(amountToSettle) || 0;
        if (settledNum <= 0) {
          pushToast('Please enter a valid payment amount greater than 0.', 'error');
          return;
        }

        const debitTx: Transaction = {
          id: `tx_recov_${Date.now()}`,
          customerId: customer.id,
          type: 'debit',
          amount: settledNum,
          date: todayStr,
          notes: `Payment receipt against Invoice #${tx.invoiceNumber || 'INV'}`,
          paymentMode: 'easypaisa',
          status: 'completed',
          responsibleStaff: staffLabel,
          auditTrail: [
            {
              id: `audit_deb_${Date.now()}`,
              timestamp: new Date().toISOString(),
              action: 'created',
              newStatus: 'completed',
              newAmount: settledNum,
              changedBy: staffLabel,
              notes: `Payment receipt recorded against invoice #${tx.invoiceNumber || 'INV'}`,
            },
          ],
          createdAt: new Date().toISOString(),
        };

        const updatedTxs: Transaction[] = transactions.map((t) => {
          if (t.id === tx.id) {
            const curDue = t.dueBalance !== undefined ? t.dueBalance : t.amount;
            const curPaid = t.paidAmount || 0;
            const newDue = Math.max(0, curDue - settledNum);
            const newStatus: 'completed' | 'partially_paid' =
              newDue === 0 ? 'completed' : 'partially_paid';
            const prevAudit = t.auditTrail || [];
            const auditLog: TransactionAuditEntry = {
              id: `audit_pay_${Date.now()}`,
              timestamp: new Date().toISOString(),
              action: 'payment_received',
              previousStatus: t.status || 'pending',
              newStatus,
              previousAmount: curDue,
              newAmount: newDue,
              changedBy: staffLabel,
              notes: `Payment of Rs. ${settledNum.toLocaleString('en-PK')} recorded. Balance now: Rs. ${newDue.toLocaleString('en-PK')}`,
            };
            return {
              ...t,
              dueBalance: newDue,
              paidAmount: curPaid + settledNum,
              status: newStatus,
              auditTrail: [auditLog, ...prevAudit],
            };
          }
          return t;
        });

        syncTransactionsAndBalances([debitTx, ...updatedTxs], customers);
        pushToast(
          `Received Rs. ${settledNum.toLocaleString('en-PK')} from ${customer.name}. Ledger updated!`,
          'success'
        );
      },
    });
  };

  // LUCKY DRAW HANDLERS
  const handleSaveLuckyDraw = (event: LuckyDrawEvent) => {
    const updated = [event, ...luckyDraws];
    setLuckyDraws(updated);
    saveLuckyDraws(updated);
  };

  const handleSendWinnerNotification = (winner: LuckyDrawWinner) => {
    const logNotif: WhatsAppNotification = {
      id: `notif_lucky_${winner.voucherCode}`,
      customerId: winner.customerId,
      customerName: winner.customerName,
      phone: winner.phone,
      amount: 0,
      scheduledFor: todayStr,
      type: 'lucky_draw_winner',
      status: 'sent',
      messageText: `Lucky draw voucher ${winner.voucherCode} dispatched for ${winner.prizeTitle}`,
      voucherCode: winner.voucherCode,
      sentAt: new Date().toISOString(),
      notes: `Lucky draw winner voucher notification`,
      createdAt: new Date().toISOString(),
    };
    const updated = [logNotif, ...notifications];
    setNotifications(updated);
    saveWhatsAppNotifications(updated);
  };

  // COMPLETE TRANSACTION AUDIT UPDATER (USER DIRECTIVE: maintain permanent audit trail of status changes & edits)
  const handleUpdateTransactionStatus = (
    txId: string,
    newStatus: 'completed' | 'pending' | 'partially_paid' | 'overdue' | 'cancelled',
    notes?: string,
    staff?: string
  ) => {
    const updated: Transaction[] = transactions.map((t) => {
      if (t.id === txId) {
        const auditLog: TransactionAuditEntry = {
          id: `audit_stat_${Date.now()}`,
          timestamp: new Date().toISOString(),
          action: 'status_updated' as const,
          previousStatus: t.status || 'pending',
          newStatus,
          changedBy:
            staff ||
            (activeRole === 'admin' || activeRole === 'super_admin'
              ? currentUser.name || 'Super Admin'
              : currentUser.name || 'Store Staff'),
          notes: notes || 'Status updated from date-wise ledger',
        };
        const prevAudit = t.auditTrail || [];
        return {
          ...t,
          status: newStatus,
          responsibleStaff: staff || t.responsibleStaff || 'Super Admin',
          auditTrail: [auditLog, ...prevAudit],
        };
      }
      return t;
    });
    setTransactions(updated);
    saveTransactions(updated);
  };

  // STANDARD TRANSACTION HANDLER
  const handleSaveTransaction = (
    txData: Omit<Transaction, 'id' | 'createdAt'>,
    sendWhatsApp: boolean
  ) => {
    const initialStatus: 'completed' | 'pending' | 'partially_paid' | 'overdue' | 'cancelled' =
      txData.status ||
      (txData.paidAmount && txData.paidAmount >= txData.amount
        ? 'completed'
        : txData.paidAmount && txData.paidAmount > 0
        ? 'partially_paid'
        : 'pending');
    const staffName =
      activeRole === 'admin' || activeRole === 'super_admin'
        ? currentUser.name || 'Super Admin'
        : currentUser.name || 'Store Staff';

    const newTx: Transaction = {
      ...txData,
      status: initialStatus,
      responsibleStaff: txData.responsibleStaff || staffName,
      auditTrail: [
        {
          id: `audit_create_${Date.now()}`,
          timestamp: new Date().toISOString(),
          action: 'created',
          newStatus: initialStatus,
          newAmount: txData.amount,
          changedBy: staffName,
          notes: txData.notes || 'Transaction created and posted to ledger',
        },
      ],
      id: `tx_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
    };

    const updatedTxs = [newTx, ...transactions];
    syncTransactionsAndBalances(updatedTxs, customers);

    const customer = customers.find((c) => c.id === txData.customerId);

    if (sendWhatsApp && customer) {
      const isCredit = txData.type === 'credit';
      const updatedBalance = isCredit ? customer.balance + txData.amount : customer.balance - txData.amount;
      const paymentChannelsText = formatPaymentChannelsText(profile.paymentChannels);

      let msg = '';
      if (isCredit) {
        msg = `*فاتورہ / بل نوٹس - ${profile.name} · مدینہ مارکیٹ*\n*Invoice Notice*\n\nمحترم ${customer.name}${customer.urduName ? ` (${customer.urduName})` : ''} صاحب،\nآپ کے کھاتے میں نیا کریڈٹ بل بنام *#${txData.invoiceNumber || 'INV'}* رقم *${profile.currencySymbol}${txData.amount.toLocaleString('en-PK')}* درج کر دیا گیا ہے۔\n\nکل بقایا واجب الادا رقم: *${profile.currencySymbol}${updatedBalance.toLocaleString('en-PK')}*\nآخری تاریخ ادائیگی: ${txData.dueDate || 'معمول کے مطابق'}\n\n${paymentChannelsText}\n\nشکریہ،\n*${profile.name}*`;
      } else {
        msg = `*رسید وصولی رقم - ${profile.name} · مدینہ مارکیٹ*\n*Payment Receipt*\n\nمحترم ${customer.name}${customer.urduName ? ` (${customer.urduName})` : ''} صاحب،\nآپ کی جانب سے مبلغ *${profile.currencySymbol}${txData.amount.toLocaleString('en-PK')}* کی وصولی بذریعہ ${txData.paymentMode?.toUpperCase() || 'ONLINE'} موصول ہوگئی ہے۔ کھاتہ اپ ڈیٹ کر دیا گیا ہے۔\n\nبقایا واجب الادا رقم: *${profile.currencySymbol}${Math.max(0, updatedBalance).toLocaleString('en-PK')}*\n\nشکریہ،\n*${profile.name}*`;
      }

      openWhatsAppDirect(customer.phone, msg);

      const logNotif: WhatsAppNotification = {
        id: `notif_tx_${Date.now()}`,
        customerId: customer.id,
        customerName: customer.name,
        phone: customer.phone,
        amount: txData.amount,
        dueDate: txData.dueDate,
        scheduledFor: todayStr,
        type: isCredit ? 'payment_reminder' : 'payment_receipt',
        status: 'sent',
        messageText: msg,
        sentAt: new Date().toISOString(),
        notes: `Instant ${isCredit ? 'credit invoice' : 'debit receipt'} notification`,
        createdAt: new Date().toISOString(),
      };
      const updatedNotifs = [logNotif, ...notifications];
      setNotifications(updatedNotifs);
      saveWhatsAppNotifications(updatedNotifs);
    }
  };

  // ADD CUSTOMER HANDLER
  const handleSaveCustomer = (
    customerData: Omit<Customer, 'id' | 'createdAt' | 'balance' | 'status'>,
    openingBalance: number
  ) => {
    const newCustId = `cust_${Date.now()}`;
    const newCust: Customer = {
      ...customerData,
      id: newCustId,
      createdAt: todayStr,
      balance: openingBalance,
      status: 'active',
      totalPurchases: openingBalance > 0 ? openingBalance : 0,
      ordersCount: openingBalance > 0 ? 1 : 0,
    };

    let updatedTxs = [...transactions];
    if (openingBalance !== 0) {
      const opTx: Transaction = {
        id: `tx_op_${Date.now()}`,
        customerId: newCustId,
        type: openingBalance > 0 ? 'credit' : 'debit',
        amount: Math.abs(openingBalance),
        date: todayStr,
        notes: 'Initial Opening Balance Due (ابتدائی بقایا رقم)',
        createdAt: new Date().toISOString(),
      };
      updatedTxs = [opTx, ...updatedTxs];
    }

    const updatedCusts = [newCust, ...customers];
    syncTransactionsAndBalances(updatedTxs, updatedCusts);
    setSelectedCustomerId(newCustId);
    setCurrentTab('customers');
  };

  // SCHEDULE WHATSAPP HANDLER
  const handleScheduleWhatsApp = (
    notifData: Omit<WhatsAppNotification, 'id' | 'createdAt' | 'status'>,
    sendImmediately: boolean
  ) => {
    const newNotif: WhatsAppNotification = {
      ...notifData,
      id: `notif_${Date.now()}`,
      status: sendImmediately ? 'sent' : 'pending',
      sentAt: sendImmediately ? new Date().toISOString() : undefined,
      createdAt: new Date().toISOString(),
    };

    const updated = [newNotif, ...notifications];
    setNotifications(updated);
    saveWhatsAppNotifications(updated);

    if (sendImmediately) {
      const updatedCusts = customers.map((c) =>
        c.id === notifData.customerId ? { ...c, lastReminderSentAt: todayStr } : c
      );
      setCustomers(updatedCusts);
      saveCustomers(updatedCusts);
    }
  };

  // RECURRING INVOICES ACTIONS
  const handleRunRecurringCheck = () => {
    const result = runRecurringInvoicesCheck(recurringInvoices, customers, profile, templates);

    if (result.generatedInvoicesCount === 0) {
      pushToast(
        'تمام مقررہ بلنگ شیڈول اپ ٹو ڈیٹ ہیں۔ All recurring billing profiles are up to date.',
        'info'
      );
      return;
    }

    const updatedTxs = [...result.newTransactions, ...transactions];
    syncTransactionsAndBalances(updatedTxs, customers);

    setRecurringInvoices(result.updatedRecurringInvoices);
    saveRecurringInvoices(result.updatedRecurringInvoices);

    if (result.newNotifications.length > 0) {
      const updatedNotifs = [...result.newNotifications, ...notifications];
      setNotifications(updatedNotifs);
      saveWhatsAppNotifications(updatedNotifs);
    }

    pushToast(
      `Successfully generated ${result.generatedInvoicesCount} recurring credit invoices.`,
      'success'
    );
  };

  const handleToggleRecurringStatus = (id: string) => {
    const updated = recurringInvoices.map((r) =>
      r.id === id ? { ...r, status: r.status === 'active' ? ('paused' as const) : ('active' as const) } : r
    );
    setRecurringInvoices(updated);
    saveRecurringInvoices(updated);
  };

  const handleDeleteRecurring = (id: string) => {
    setConfirmDialog({
      title: 'Delete Recurring Schedule',
      message: 'اس مقررہ بلنگ شیڈول کو خارج کریں؟ Delete this recurring billing schedule?',
      confirmLabel: 'Delete',
      danger: true,
      onConfirm: () => {
        const updated = recurringInvoices.filter((r) => r.id !== id);
        setRecurringInvoices(updated);
        saveRecurringInvoices(updated);
        void apiDeleteCollectionItem('recurring_invoices', id);
        pushToast('Recurring schedule deleted.', 'info');
      },
    });
  };

  // OPEN MODALS
  const openAddTransaction = (type?: unknown, customerId?: unknown) => {
    const validType = (type === 'debit') ? 'debit' : 'credit';
    setAddTxType(validType);
    setAddTxCustomerId(typeof customerId === 'string' ? customerId : selectedCustomerId);
    setIsAddTxOpen(true);
  };

  const openScheduleWhatsApp = (customerId?: unknown, date?: unknown) => {
    setScheduleCustomerId(typeof customerId === 'string' ? customerId : selectedCustomerId);
    setScheduleDate(typeof date === 'string' ? date : undefined);
    setIsScheduleWhatsAppOpen(true);
  };

  const openInvoiceModal = (tx: Transaction, customer: Customer) => {
    setInvoiceModalTx(tx);
    setInvoiceModalCustomer(customer);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors">
      {/* Top Navbar with Yellow Bar (Matching Screenshot Exact Theme) */}
      <Navbar
        currentTab={currentTab}
        onTabChange={handleTabChange}
        onOpenAddTransaction={() => openAddTransaction('credit')}
        onOpenCart={() => setIsCheckoutOpen(true)}
        cartCount={cartCount}
        cartTotal={cartTotal}
        pendingAlertsCount={pendingAlertsCount}
        codPendingCount={codOrders.filter((o) => o.status === 'pending' || o.status === 'dispatched').length}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        searchQuery={searchQuery}
        onSearchChange={(q) => setSearchQuery(q)}
        selectedCategory={selectedCategory}
        onCategoryChange={(cat) => setSelectedCategory(cat)}
        categories={allCategories}
        categoryRecords={categoryRecords}
        products={products}
        onOpenCategoryModal={() => setIsCategoryModalOpen(true)}
        profile={profile}
        viewMode={viewMode}
        onToggleViewMode={setViewMode}
        userRole={activeRole}
        currentUser={currentUser}
        onOpenRoleModal={openRoleModal}
      />

      {/* Security Reminder Banner: Prompt Customer to Change Default Password (USER DIRECTIVE) */}
      {(currentUser.mustChangePassword || currentUser.hasDefaultPin) && activeRole === 'customer' && (
        <div className="bg-amber-500 text-slate-950 px-3 sm:px-6 lg:px-8 py-2 text-xs font-bold flex items-center justify-between gap-2 shadow-xs border-b border-amber-600 no-print">
          <div className="flex items-center gap-2 w-full justify-between">
            <span className="flex items-center gap-1.5">
              <Lock className="w-4 h-4 shrink-0" />
              <span>
                سیکیورٹی یاددہانی: آپ عارضی پاس ورڈ استعمال کر رہے ہیں۔ اپنے کھاتے اور آرڈرز کو محفوظ رکھنے کے لیے نیا پرائیویٹ پاس ورڈ سیٹ کریں۔
                <span className="hidden sm:inline font-normal text-slate-900 ml-1">
                  (Please replace your temporary password with a private password to secure your account)
                </span>
              </span>
            </span>
            <button
              type="button"
              onClick={openRoleModal}
              className="px-2.5 py-1 bg-slate-950 text-white hover:bg-slate-900 rounded-md text-[11px] font-extrabold whitespace-nowrap cursor-pointer shrink-0 transition-colors"
            >
              پاس ورڈ تبدیل کریں (Change Password)
            </button>
          </div>
        </div>
      )}

      {/* Main Content Body (Full-width desktop layout with mobile-friendly responsive padding) */}
      <main className="flex-1 w-full px-3 sm:px-5 md:px-6 lg:px-8 py-3 sm:py-6">
        {/* 1. STORE & POS CATALOG VIEW (Default View Matching Screenshot) */}
        {currentTab === 'store' && (
          <StoreCatalogView
            products={products}
            customers={customers}
            profile={profile}
            cart={cart}
            categoryRecords={categoryRecords}
            onAddToCart={handleAddToCart}
            onUpdateCartQty={handleUpdateCartQty}
            onRemoveFromCart={handleRemoveFromCart}
            onClearCart={handleClearCart}
            onOpenCheckout={() => setIsCheckoutOpen(true)}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
            onOpenImportModal={() => {
              setIsWebsiteImportModalOpen(true);
            }}
            onOpenCategoryModal={() => setIsCategoryModalOpen(true)}
            isCustomerView={viewMode === 'customer' || activeRole === 'customer'}
            hideCostPrice={viewMode === 'customer' || activeRole === 'customer'}
            userRole={activeRole}
            currentUser={currentUser}
            investors={investors}
            initialProductId={initialProductId}
            onClearInitialProduct={() => {
              setInitialProductId(null);
              try {
                const url = new URL(window.location.href);
                if (url.searchParams.has('product')) {
                  url.searchParams.delete('product');
                  window.history.replaceState({}, '', url.pathname + url.search + url.hash);
                }
              } catch {
                // ignore history errors
              }
            }}
            onUpdateProduct={handleSaveProduct}
          />
        )}

        {/* WALK-IN CUSTOMER POS SALES TERMINAL */}
        {currentTab === 'walkin_pos' && (
          <WalkInSalesView
            products={products}
            currentUser={currentUser}
            onStockUpdated={(updatedProds) => {
              setProducts(updatedProds);
              saveProducts(updatedProds);
            }}
          />
        )}

        {/* STORE MANAGERS & MULTI-BRANCH MANAGEMENT */}
        {currentTab === 'branches_manage' && (
          <BranchManagementView
            currentUserRole={activeRole}
            currentUser={currentUser}
            onRefreshSession={handleRefreshAllData}
            onOpenWalkInTerminal={() => setCurrentTab('walkin_pos')}
          />
        )}

        {/* CUSTOMER SELF-SERVICE PORTAL */}
        {(currentTab === 'customer_portal' || currentTab === 'customer_tickets') && (
          <CustomerPortalView
            currentUser={currentUser}
            customer={customers.find(
              (c) =>
                c.id === currentUser.customerId ||
                (currentUser.phone && c.phone.replace(/\D/g, '') === currentUser.phone.replace(/\D/g, ''))
            )}
            transactions={transactions}
            codOrders={codOrders}
            profile={profile}
            initialTab={currentTab === 'customer_tickets' ? 'tickets' : 'dashboard'}
            onLogout={handleLogout}
            onOpenCart={() => setIsCheckoutOpen(true)}
            onNavigateTab={handleTabChange}
            onUpdateCustomer={(updatedCust) => {
              const updated = customers.map((c) => (c.id === updatedCust.id ? updatedCust : c));
              setCustomers(updated);
              saveCustomers(updated);
              pushToast('Delivery address updated.', 'success');
            }}
            onPasswordChanged={() => {
              const updatedUser: AppUser = {
                ...currentUser,
                mustChangePassword: false,
                hasDefaultPin: false,
              };
              setCurrentUser(updatedUser);
              saveCurrentUser(updatedUser);
              setCustomers(getCustomers());
              pushToast('Password changed successfully.', 'success');
            }}
          />
        )}

        {/* INVESTOR MANAGEMENT & PORTFOLIO */}
        {currentTab === 'investors' && (
          <InvestorManagementView
            currentUser={currentUser}
            userRole={activeRole}
            products={products}
            codOrders={codOrders}
            profile={profile}
            investorsList={investors}
            onInvestorsUpdated={(updated) => setInvestors(updated)}
            onProductInvestorSynced={(updatedProds) => {
              setProducts(updatedProds);
              saveProducts(updatedProds);
            }}
          />
        )}

        {/* USER CREDENTIALS & SECURITY MANAGEMENT */}
        {currentTab === 'users' && (
          <UserManagementView
            currentUserRole={activeRole}
            onRefreshSession={handleRefreshAllData}
          />
        )}

        {/* COD ORDERS & LOGISTICS HUB (USER DIRECTIVE: separate area for cod order and delivered process etc return etc with auto calculation once status is changed) */}
        {currentTab === 'cod_orders' && (
          <CODOrdersView
            orders={codOrders}
            products={products}
            customers={customers}
            profile={profile}
            userRole={activeRole}
            onAuditRepairOrders={handleAuditRepairOrders}
            onUpdateOrderStatus={handleUpdateCODStatus}
            onAddNewCODOrder={handleAddNewCODOrder}
          />
        )}

        {/* HR MANAGEMENT, ALLOWANCES & ATTENDANCE (USER DIRECTIVE: Add HR hiring, package with allowances attendance auto calculation salaries role base hiring) */}
        {currentTab === 'hr_payroll' && (
          <HRManagementView
            employees={employees}
            attendance={attendance}
            profile={profile}
            onSaveEmployee={handleSaveEmployee}
            onSaveAttendance={handleSaveAttendance}
            onDeleteEmployee={handleDeleteEmployee}
            onDeleteAttendance={handleDeleteAttendance}
          />
        )}

        {/* RESELLERS AFFILIATE COMMISSION PORTAL (USER DIRECTIVE: do not public resallers information only for resaller of admin) */}
        {currentTab === 'resellers' && (
          activeRole === 'customer' ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-10 text-center max-w-md mx-auto space-y-3 shadow-xs my-8">
              <div className="w-12 h-12 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 flex items-center justify-center mx-auto">
                <Lock className="w-6 h-6" />
              </div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Reseller Portal Restricted / ری سیلر پورٹل
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Reseller accounts and commission ledgers are private and accessible only by registered reseller partners and store administration.
              </p>
              <button
                onClick={() => setCurrentTab('store')}
                className="px-4 py-2 bg-slate-900 text-white dark:bg-amber-500 dark:text-slate-950 rounded-lg text-xs font-bold cursor-pointer"
              >
                Back to Market Catalog (مارکیٹ پر جائیں)
              </button>
            </div>
          ) : (
            <ResellersView
              resellers={resellers}
              profile={profile}
              onSaveReseller={handleSaveReseller}
              onPayoutCommission={handlePayoutCommission}
              isResellerRole={activeRole === 'reseller'}
              activeResellerCode={currentUser.resellerCode}
            />
          )
        )}

        {/* MONTHLY STATEMENTS & WINNING AMOUNTS VIEW (USER DIRECTIVE: customer scoped) */}
        {currentTab === 'monthly_statement' && (
          <MonthlyStatementView
            customers={customers}
            transactions={transactions}
            luckyDraws={luckyDraws}
            profile={profile}
            userRole={activeRole}
            currentUser={currentUser}
          />
        )}

        {/* 2. INVENTORY & WINNING ITEMS VIEW */}
        {currentTab === 'inventory' && (
          <InventoryView
            products={products}
            profile={profile}
            currentUser={currentUser}
            categoryRecords={categoryRecords}
            investors={investors}
            onRefreshProducts={handleRefreshAllData}
            onSaveProduct={handleSaveProduct}
            onUpdateStock={handleUpdateStock}
            onToggleWinningItem={handleToggleWinningItem}
            onDeleteProduct={handleDeleteProduct}
            isExternalImportOpen={isWebsiteImportModalOpen}
            onCloseExternalImport={() => setIsWebsiteImportModalOpen(false)}
            onOpenCategoryModal={() => setIsCategoryModalOpen(true)}
          />
        )}

        {/* 3. PAYMENT TERMS & 3-DAY REMINDERS VIEW */}
        {currentTab === 'payment_terms' && (
          <PaymentTermsView
            transactions={transactions}
            customers={customers}
            profile={profile}
            templates={templates}
            onRunTermsEngine={handleRunPaymentTermsEngine}
            onSendSingleReminder={handleSendSingleTermsReminder}
            onSettlePayment={handleSettleTermsPayment}
          />
        )}

        {/* 4. TOP 3 BUYERS & LUCKY DRAW VIEW */}
        {currentTab === 'lucky_draw' && (
          <LuckyDrawView
            topBuyers={topBuyers}
            luckyDraws={luckyDraws}
            profile={profile}
            templates={templates}
            onSaveLuckyDraw={handleSaveLuckyDraw}
            onSendWinnerNotification={handleSendWinnerNotification}
            isCustomerView={viewMode === 'customer' || activeRole === 'customer'}
          />
        )}

        {/* 5. DASHBOARD & LEDGER OVERVIEW */}
        {currentTab === 'dashboard' && (
          <DashboardView
            customers={customers}
            transactions={transactions}
            recurringInvoices={recurringInvoices}
            notifications={notifications}
            profile={profile}
            onOpenAddTransaction={openAddTransaction}
            onOpenAddCustomer={() => setIsAddCustomerOpen(true)}
            onOpenScheduleWhatsApp={openScheduleWhatsApp}
            onOpenInvoiceModal={openInvoiceModal}
            onSelectCustomer={(cId) => {
              setSelectedCustomerId(cId);
              setCurrentTab('customers');
            }}
            onRunRecurringCheck={handleRunRecurringCheck}
            onRunMonthlyReminderBatch={() => {
              const newNotifs = generateMonthlyRemindersBatch(customers, profile, templates);
              if (newNotifs.length > 0) {
                const updated = [...newNotifs, ...notifications];
                setNotifications(updated);
                saveWhatsAppNotifications(updated);
                setCurrentTab('whatsapp');
                pushToast(`Queued monthly statements for ${newNotifs.length} customers.`, 'success');
              } else {
                pushToast('All customer accounts are clear!', 'info');
              }
            }}
            onRunWeeklyDueReminders={() => {
              const newNotifs = generateWeeklyDueRemindersBatch(customers, profile, templates);
              if (newNotifs.length > 0) {
                const updated = [...newNotifs, ...notifications];
                setNotifications(updated);
                saveWhatsAppNotifications(updated);
                setCurrentTab('whatsapp');
                pushToast(`Queued weekly due reminders for ${newNotifs.length} customers.`, 'success');
              } else {
                pushToast('All accounts are clear!', 'info');
              }
            }}
            onOpenProductBroadcast={() => setIsProductBroadcastOpen(true)}
            onMarkNotificationSent={(id) => {
              const updated = notifications.map((n) =>
                n.id === id ? { ...n, status: 'sent' as const, sentAt: new Date().toISOString() } : n
              );
              setNotifications(updated);
              saveWhatsAppNotifications(updated);
            }}
            onNavigateTab={(tab) => setCurrentTab(tab)}
          />
        )}

        {/* 6. CUSTOMERS & KHATTA LEDGER */}
        {currentTab === 'customers' && (
          <CustomersView
            customers={customers}
            transactions={transactions}
            profile={profile}
            selectedCustomerId={selectedCustomerId}
            onSelectCustomer={(cId) => setSelectedCustomerId(cId)}
            onOpenCrmProfile={(cId) => {
              setCrmCustomerFocusId(cId);
              handleTabChange('crm');
            }}
            onOpenAddCustomer={() => setIsAddCustomerOpen(true)}
            onOpenAddTransaction={openAddTransaction}
            onOpenScheduleWhatsApp={openScheduleWhatsApp}
            onOpenInvoiceModal={openInvoiceModal}
            onUpdateCustomer={(updatedCust) => {
              const updated = customers.map((c) => (c.id === updatedCust.id ? updatedCust : c));
              setCustomers(updated);
              saveCustomers(updated);
              pushToast(`Updated delivery address for ${updatedCust.name}.`, 'success');
            }}
            onDeleteTransaction={(txId) => {
              setConfirmDialog({
                title: 'Delete Transaction',
                message: 'Are you sure you want to permanently delete this ledger transaction?',
                confirmLabel: 'Delete',
                danger: true,
                onConfirm: () => {
                  const updated = transactions.filter((t) => t.id !== txId);
                  syncTransactionsAndBalances(updated, customers);
                  void apiDeleteCollectionItem('transactions', txId);
                  pushToast('Transaction deleted.', 'info');
                },
              });
            }}
          />
        )}

        {/* 6B. INTEGRATED CRM & RETENTION WORKSPACE */}
        {currentTab === 'crm' && (
          <CRMWorkspaceView
            currentUser={currentUser}
            profile={profile}
            products={products}
            initialCustomerId={crmCustomerFocusId}
            onClearInitialCustomer={() => setCrmCustomerFocusId(undefined)}
            onOpenCustomerKhata={(custId) => {
              setSelectedCustomerId(custId);
              handleTabChange('customers');
            }}
            onRefreshGlobalData={handleRefreshAllData}
          />
        )}

        {/* 7. RECURRING BILLING CONTRACTS */}
        {currentTab === 'recurring' && (
          <RecurringInvoicesView
            recurringInvoices={recurringInvoices}
            customers={customers}
            transactions={transactions}
            profile={profile}
            onOpenAddRecurring={() => setIsAddRecurringOpen(true)}
            onRunRecurringCheck={handleRunRecurringCheck}
            onToggleStatus={handleToggleRecurringStatus}
            onDeleteRecurring={handleDeleteRecurring}
            onTriggerSingleRecurring={(rec) => {
              pushToast(`Contract ${rec.title} triggered.`, 'success');
            }}
            onOpenInvoiceModal={openInvoiceModal}
          />
        )}

        {/* 8. WHATSAPP NOTIFICATIONS QUEUE */}
        {currentTab === 'whatsapp' && (
          <WhatsAppAutomationView
            notifications={notifications}
            customers={customers}
            templates={templates}
            profile={profile}
            productBroadcasts={productBroadcasts}
            manualContacts={broadcastContacts}
            savedBroadcasts={savedBroadcasts}
            onOpenScheduleWhatsApp={openScheduleWhatsApp}
            onOpenProductBroadcast={() => setIsProductBroadcastOpen(true)}
            onSaveManualContact={handleSaveBroadcastContact}
            onDeleteManualContact={handleDeleteBroadcastContact}
            onResendSavedBroadcast={(camp) => {
              const product: ProductBroadcast = {
                id: `prod_resend_${Date.now()}`,
                productName: camp.productName,
                productLink: camp.productLink || 'https://madinamarket.pk',
                description: camp.messageText,
                createdAt: new Date().toISOString().split('T')[0],
              };
              const newNotifs = generateSegmentedBroadcastBatch(
                product,
                customers,
                broadcastContacts,
                camp.filters,
                profile,
                templates
              );
              if (newNotifs.length > 0) {
                const updated = [...newNotifs, ...notifications];
                setNotifications(updated);
                saveWhatsAppNotifications(updated);
                pushToast(`Re-queued broadcast to ${newNotifs.length} matching recipients!`, 'success');
              } else {
                pushToast('No matching recipients found for this saved campaign.', 'warning');
              }
            }}
            onRunWeeklyDueReminders={() => {
              const newNotifs = generateWeeklyDueRemindersBatch(customers, profile, templates);
              if (newNotifs.length > 0) {
                const updated = [...newNotifs, ...notifications];
                setNotifications(updated);
                saveWhatsAppNotifications(updated);
              }
            }}
            onMarkNotificationSent={(id) => {
              const updated = notifications.map((n) =>
                n.id === id ? { ...n, status: 'sent' as const, sentAt: new Date().toISOString() } : n
              );
              setNotifications(updated);
              saveWhatsAppNotifications(updated);
            }}
            onDeleteNotification={(id) => {
              const updated = notifications.filter((n) => n.id !== id);
              setNotifications(updated);
              saveWhatsAppNotifications(updated);
              void apiDeleteCollectionItem('notifications', id);
            }}
            onUpdateTemplates={(updated) => {
              setTemplates(updated);
              saveReminderTemplates(updated);
            }}
            onRunMonthlyReminderBatch={() => {
              const newNotifs = generateMonthlyRemindersBatch(customers, profile, templates);
              if (newNotifs.length > 0) {
                const updated = [...newNotifs, ...notifications];
                setNotifications(updated);
                saveWhatsAppNotifications(updated);
              }
            }}
          />
        )}

        {/* 9. REPORTS & SAVINGS PORTAL (CUSTOMER & ADMIN SCOPED) */}
        {currentTab === 'reports' && (
          <ReportsView
            transactions={transactions}
            customers={customers}
            profile={profile}
            codOrders={codOrders}
            products={products}
            onOpenInvoiceModal={openInvoiceModal}
            userRole={activeRole}
            currentUser={currentUser}
            onOpenFinancialMaster={
              activeRole === 'super_admin' || activeRole === 'admin' || activeRole === 'manager'
                ? () => handleTabChange('financial_master')
                : undefined
            }
          />
        )}

        {/* 9B. FINANCIAL MASTER FILE, MONTHLY EXPENSES & BREAKEVEN ENGINE */}
        {currentTab === 'financial_master' && (
          <FinancialMasterView
            transactions={transactions}
            customers={customers}
            products={products}
            codOrders={codOrders}
            employees={employees}
            attendance={attendance}
            resellers={resellers}
            investors={investors}
            profile={profile}
            monthlyExpenses={monthlyExpenses}
            onSaveExpense={handleSaveMonthlyExpense}
            onDeleteExpense={handleDeleteMonthlyExpense}
            onCloneRecurringExpenses={handleCloneRecurringExpenses}
            currentUser={currentUser}
            onNavigateTab={handleTabChange}
          />
        )}

        {/* 10. COMPLETE DATE-WISE TRANSACTION HISTORY & AUDIT LEDGER */}
        {currentTab === 'history' && (
          <TransactionHistoryView
            transactions={transactions}
            customers={customers}
            profile={profile}
            userRole={activeRole}
            currentUser={currentUser}
            onOpenInvoiceModal={openInvoiceModal}
            onUpdateTransactionStatus={handleUpdateTransactionStatus}
            onAuditRepairOrders={handleAuditRepairOrders}
          />
        )}

        {/* 10. SETTINGS VIEW */}
        {currentTab === 'settings' && (
          <SettingsView
            profile={profile}
            onSaveProfile={(updated) => {
              setProfile(updated);
              saveBusinessProfile(updated);
            }}
            onRefreshAllData={handleRefreshAllData}
            customers={customers}
            resellers={resellers}
            onUpdateCustomer={(updatedCust) => {
              const updated = customers.map((c) => (c.id === updatedCust.id ? updatedCust : c));
              setCustomers(updated);
              saveCustomers(updated);
            }}
            onUpdateReseller={(updatedReseller) => {
              const updated = resellers.map((r) => (r.id === updatedReseller.id ? updatedReseller : r));
              setResellers(updated);
              saveResellers(updated);
            }}
          />
        )}
      </main>

      {/* Pakistani Business Footer (USER DIRECTIVE: hide payment phone numbers from footer, use single number only in checkout) */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-4 no-print transition-colors">
        <div className="w-full px-3 sm:px-5 md:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 dark:text-slate-400 gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-extrabold text-slate-900 dark:text-white">100DAGAR</span>
            <span>·</span>
            <span className="inline-flex items-center gap-1 font-semibold text-[11px] text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-0.5 rounded-md">
              EasyPaisa Verified
            </span>
            <span className="inline-flex items-center gap-1 font-semibold text-[11px] text-red-800 dark:text-red-300 bg-red-50 dark:bg-red-950/60 px-2.5 py-0.5 rounded-md">
              JazzCash Verified
            </span>
            <span className="inline-flex items-center gap-1 font-semibold text-[11px] text-blue-800 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/60 px-2.5 py-0.5 rounded-md">
              SadaPay Verified
            </span>
            <span className="inline-flex items-center gap-1 font-semibold text-[11px] text-slate-800 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2.5 py-0.5 rounded-md">
              Cash on Delivery (COD) Available
            </span>
          </div>
          <div className="flex items-center gap-2 text-[11px]">
            <button
              onClick={() => {
                setIsRoleModalOpen(true);
              }}
              className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 underline cursor-pointer"
            >
              Staff / Admin Portal
            </button>
          </div>
        </div>
      </footer>

      {/* POS CHECKOUT MODAL (Credit Sale strictly gated by Seller Role Authorization) */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cart={cart}
        customers={customers}
        profile={profile}
        isCustomerView={viewMode === 'customer' || activeRole === 'customer'}
        isAdmin={activeRole === 'admin' || activeRole === 'super_admin'}
        currentUser={currentUser}
        onCompleteSale={handleCompleteSale}
        onUpdateCartQty={handleUpdateCartQty}
        onRemoveFromCart={handleRemoveFromCart}
        onClearCart={handleClearCart}
        onSaveProfile={(updated) => {
          setProfile(updated);
          saveBusinessProfile(updated);
        }}
      />

      {/* LOGIN & USER ROLE SWITCHER MODAL */}
      <LoginRoleModal
        isOpen={isRoleModalOpen}
        onClose={() => setIsRoleModalOpen(false)}
        currentUser={currentUser}
        customers={customers}
        resellers={resellers}
        onSelectRole={handleSelectRole}
        onLogout={handleLogout}
      />

      {/* STANDARD MODALS */}
      <AddTransactionModal
        isOpen={isAddTxOpen}
        onClose={() => setIsAddTxOpen(false)}
        onSave={handleSaveTransaction}
        customers={customers}
        profile={profile}
        initialType={addTxType}
        initialCustomerId={addTxCustomerId}
      />

      <AddCustomerModal
        isOpen={isAddCustomerOpen}
        onClose={() => setIsAddCustomerOpen(false)}
        onSave={handleSaveCustomer}
        profile={profile}
      />

      <ScheduleWhatsAppModal
        isOpen={isScheduleWhatsAppOpen}
        onClose={() => setIsScheduleWhatsAppOpen(false)}
        onSchedule={handleScheduleWhatsApp}
        customers={customers}
        templates={templates}
        profile={profile}
        initialCustomerId={scheduleCustomerId}
        initialDate={scheduleDate}
      />

      <AddRecurringInvoiceModal
        isOpen={isAddRecurringOpen}
        onClose={() => setIsAddRecurringOpen(false)}
        onSave={(recData) => {
          const newRec: RecurringInvoice = {
            ...recData,
            id: `rec_${Date.now()}`,
            createdAt: new Date().toISOString(),
          };
          const updated = [newRec, ...recurringInvoices];
          setRecurringInvoices(updated);
          saveRecurringInvoices(updated);
        }}
        customers={customers}
        profile={profile}
        initialCustomerId={selectedCustomerId}
      />

      <ProductBroadcastModal
        isOpen={isProductBroadcastOpen}
        onClose={() => setIsProductBroadcastOpen(false)}
        customers={customers}
        manualContacts={broadcastContacts}
        profile={profile}
        templates={templates}
        onBroadcast={(product, filters, sendFirst, saveCampaign) => {
          const newNotifs = generateSegmentedBroadcastBatch(
            product,
            customers,
            broadcastContacts,
            filters,
            profile,
            templates
          );

          if (newNotifs.length > 0) {
            if (sendFirst && newNotifs[0]) {
              openWhatsAppDirect(newNotifs[0].phone, newNotifs[0].messageText);
            }
            const updated = [...newNotifs, ...notifications];
            setNotifications(updated);
            saveWhatsAppNotifications(updated);

            if (saveCampaign) {
              const campaign: SavedBroadcastCampaign = {
                id: `camp_${Date.now()}`,
                title: `Broadcast: ${product.productName}`,
                productName: product.productName,
                productLink: product.productLink,
                messageText: newNotifs[0].messageText,
                filters: {
                  area: filters.area,
                  ageGroup: filters.ageGroup,
                  gender: filters.gender,
                  customerGroup: filters.group,
                },
                recipientsCount: newNotifs.length,
                sentAt: new Date().toLocaleString(),
                createdAt: new Date().toISOString(),
              };
              handleSaveBroadcastCampaign(campaign);
            }

            pushToast(`Queued broadcast to ${newNotifs.length} matching recipients (Customers & Leads)!`, 'success');
          } else {
            pushToast('No matching customers or manual contacts found with these segmentation filters.', 'warning');
          }
          setIsProductBroadcastOpen(false);
        }}
      />

      {invoiceModalTx && invoiceModalCustomer && (
        <InvoiceModal
          isOpen={!!invoiceModalTx}
          onClose={() => {
            setInvoiceModalTx(null);
            setInvoiceModalCustomer(null);
          }}
          transaction={invoiceModalTx}
          customer={invoiceModalCustomer}
          profile={profile}
        />
      )}

      {/* CATEGORY CLEANUP & PARENT/SUB-CATEGORY MANAGEMENT MODAL */}
      <CategoryManagementModal
        isOpen={isCategoryModalOpen}
        onClose={() => setIsCategoryModalOpen(false)}
        products={products}
        onCategoriesUpdated={() => {
          handleRefreshAllData();
        }}
      />

      {/* COMPLETE WEBSITE PRODUCT IMPORTER MODAL (Accessible from Store Catalog & Inventory) */}
      <ProductImporterModal
        isOpen={isWebsiteImportModalOpen}
        onClose={() => setIsWebsiteImportModalOpen(false)}
        existingProducts={products}
        onSaveProduct={handleSaveProduct}
      />

      {/* GLOBAL NON-BLOCKING TOASTS, CONFIRMATIONS & PROMPTS */}
      <ToastBanner toasts={toasts} onDismiss={dismissToast} />
      <ConfirmDialogModal
        dialog={confirmDialog}
        onClose={() => setConfirmDialog(null)}
      />
      <InputPromptModal
        promptState={inputPrompt}
        onClose={() => setInputPrompt(null)}
      />
    </div>
  );
}
